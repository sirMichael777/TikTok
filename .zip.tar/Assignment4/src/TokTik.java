/**
 * @author Michael Maseko
 * The main class of my TokTik, it just calls the menu which is a gui
 */
public class TokTik{
    /**
     * Main method for running our app
     * @param args arguments
     */
    public static void main(String[] args) {
        new Menu();
    }
}