/**
 * Class that just creates and store a binary search tree for storing accounts
 * @author Michael Maseko
 */
public class TokTikTree{
    /**A variable of type BinaryTree which we used as a storage device for storing all the users' accounts
     * 
     */
    public static BinaryTree<Account> AccountsTree = new BinaryTree<Account>();
}